<br>
<br>
<div class="fixed-bottom bg-dark text-light container-fluid">
    <br>
    <p class="float-right">Denim Feder-McDonald &copy</p>
    <br>
    <br>
</div>