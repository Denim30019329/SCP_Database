<div class="text-light bg-dark sticky-top w-100">
    <div class="container-fluid pt-2 d-flex">
        <div class="">
            <img style="width:80px;" class="image-fluid pt-1" src="images/logo/Logo_of_the_SCP_Foundation.png" alt="" />
        </div>
        <div class="container-fluid pl-4" style="font-family: 'Volkhov', serif;">
            <h1 class="remove-500">SCP Foundation</h1>
            <h6 class="remove-500">Secure, Contain, Protect</h6>
        </div>
    </div>
    <nav class="navbar navbar-expand-sm navbar-dark d-flex">
        <a class="navbar-brand" href="index.php">SCP Files</a>
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" href="create.php">Add New Item</a>
            </li>
        </ul>
    </nav>
</div>