<?php

if($_POST)
{                         
    if (isset($_FILES['file'])) 
    {   
        $oldImagePath = $_imagePathName;        
        
        $query = "UPDATE item SET _itemNumber=:_itemNumber, _imagePathName=:_imagePathName, _type=:_type, _scp=:_scp, _description=:_description WHERE _itemID='$id'";
            
        //prepare the query
        $update = $conn->prepare($query);
        
        $file = $_FILES['file'];

        $fileName = $_FILES['file']['name'];
        $fileTmpName = $_FILES['file']['tmp_name'];
        $fileSize = $_FILES['file']['size'];
        $fileError = $_FILES['file']['error'];
        $fileType = $_FILES['file']['type'];

        //checking if a jpg, jpeg or png
        $fileExt = explode('.', $fileName);
        $fileAuctualExt = strtolower(end($fileExt));

        $allowed = array('jpg', 'jpeg', 'png');

        if (in_array($fileAuctualExt, $allowed))
        {
            if ($fileError === 0) 
            {
                if ($fileSize < 10000000) 
                {
                    $fileNameNew = uniqid('', true).".".$fileAuctualExt;
                    $fileDestination = 'images/'.$fileNameNew;
                    
                    move_uploaded_file($fileTmpName, $fileDestination);

                    $update->bindParam('_imagePathName', $fileDestination);

                    $_itemNumber = htmlspecialchars(strip_tags($_POST['_itemNumber']));                    
                    $_type = htmlspecialchars(strip_tags($_POST['_type']));               
                    $_scp = $_POST['_scp'];
                    $_description = $_POST['_description'];
                
                    //bind the parameters
                    $update->bindParam(':_itemNumber', $_itemNumber);
                    $update->bindParam(':_type', $_type);
                    $update->bindParam(':_scp', $_scp);
                    $update->bindParam(':_description', $_description);

                    array_map('unlink', glob("$oldImagePath"));
                    
                }
                else
                {
                    echo "Your file was to large.";
                }
            }
            else
            {
                echo "There was a error.";
            }
        } 
        else 
        {
            echo "You cannot upload files of this type!";
        }
        
        $update->execute();
        
    }
    if($_POST['submit'])
    {
        $query = "UPDATE item SET _itemNumber=:_itemNumber, _type=:_type, _scp=:_scp, _description=:_description WHERE _itemID='$id'";

        //prepare the query
        $update = $conn->prepare($query);

        //save the post values from the form
        $_type = htmlspecialchars(strip_tags($_POST['_type']));
        $_itemNumber = htmlspecialchars(strip_tags($_POST['_itemNumber']));                    
        $_scp = $_POST['_scp'];
        $_description = $_POST['_description'];

        //bind the parameters
        $update->bindParam(':_type', $_type);
        $update->bindParam(':_scp', $_scp);
        $update->bindParam(':_description', $_description);
        $update->bindParam(':_itemNumber', $_itemNumber);

        $update->execute();      
    }        
                                                   
}
        
?>