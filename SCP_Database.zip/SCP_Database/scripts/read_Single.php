<?php 
       
    if(isset($_GET['id']))
    {
        $id = $_GET['id'];
    }
    else
    {
        die('ERROR: Record id not found');
    }
      
    try
    {
        $sql = "SELECT _itemID, _itemNumber, _type, _scp, _imagePathName, _description, _created, _modified FROM item WHERE _itemID = ? LIMIT 0,1";
        $statement = $conn->prepare($sql);
                       
        $statement->bindParam(1, $id);
        $statement->execute();

        $row = $statement->fetch(PDO::FETCH_ASSOC);
                       
        //individual values from the record 
        $_itemNumber = $row['_itemNumber'];
        $_type = $row['_type'];
        $_scp = $row['_scp'];
        $_imagePathName = $row['_imagePathName'];
        $_description = $row['_description'];
        $_created = $row['_created'];
        $_modified = $row['_modified'];           
          
    }
    catch(PDOException $exception)
    {
        die('ERROR: ' . $exception->getMessage());
    }
       
?>