<?php 
 
$host = "localhost"; 
$db = "a3001932_SCP"; 
$user = "a3001932_Denim"; 
$pwd = "Toiohomai1234";

$dsn = "mysql:host=$host; dbname=$db;";
  
try {  
    $conn = new PDO($dsn, $user, $pwd); 
} catch(PDOException $e) 
{
    echo "Error: " . $e->getMessage(); 
} 

?>